# Music Streaming Website Frontend

![Project Image](./readme_image.png)

> This is a Music Streaming Website's FrontEnd similar to spotify, saavn etc.
> You can view the project here: https://lakshdhamija.github.io/music_Streaming_Website_Frontend-HTML-CSS/

---

### Table of Contents

- [Description](#description)
- [Author Info](#author-info)

---

## Description

This frontEnd project was made only using HTML and CSS. It has been made fully responsive to adapt to any screen size using media queries.

#### Technologies

- HTML
- CSS

[Back To The Top](#read-me-template)

---

## Author Info

- LinkedIn - [@lakshDhamija](https://linkedin.com/in/laksh-dhamija)

[Back To The Top](#read-me-template)
